package ex4;

public class Ex4 {
	
	public static void main(String args[]) {
		
		int soma = 0;
		for(int i=0; i<=100; i++) {
			soma += i;
		}
		System.out.println(soma);
	}
}
