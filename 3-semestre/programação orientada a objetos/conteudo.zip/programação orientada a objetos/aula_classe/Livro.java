package pkg;

public class Livro {
	public String titulo;
	public String autor;
	public int anoPublicacao;
}
