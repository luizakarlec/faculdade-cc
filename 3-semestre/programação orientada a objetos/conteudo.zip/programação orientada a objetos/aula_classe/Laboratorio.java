package pkg;

public class Laboratorio {
	public String local;

}
