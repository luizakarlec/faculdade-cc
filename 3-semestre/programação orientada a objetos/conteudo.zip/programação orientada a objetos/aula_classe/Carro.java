package pkg;

public class Carro {
	public String marca;
	public String modelo;
	public int anoFabricacao;
}
