package pkg;

public class Professor {
	public String nome;

}
