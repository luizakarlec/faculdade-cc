package pkg;

public class Computador {
	public String marca;
	public String modelo;
	public String tipo;
	public double preco;
}
