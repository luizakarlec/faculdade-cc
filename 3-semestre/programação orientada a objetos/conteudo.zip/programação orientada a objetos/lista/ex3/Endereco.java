package pkg3;

public class Endereco {
	private String rua;
	private int numero;
	
	public Endereco(String rua, int numero) {
		super();
		this.rua = rua;
		this.numero = numero;
	}
	
	public String getRua() {
		return rua;
	}
	public int getNumero() {
		return numero;
	}
	
}
