package ex3;

public class Principal {

	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		p.falar("oiii");
		p.falar("oie!", 3);
	}
}
