package ex2;

public class ContaBancaria {
	public double saldo;
	
	public void calcularSaldo() {
		System.out.println("saldo da conta bancária : "+saldo);
	}
}
