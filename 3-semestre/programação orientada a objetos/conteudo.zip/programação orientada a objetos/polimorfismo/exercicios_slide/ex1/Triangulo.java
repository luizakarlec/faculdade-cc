package ex1;

public class Triangulo extends FormaGeometrica {

	@Override
	public double calcularArea() {
		return (base * altura) / 2;
	}
}
