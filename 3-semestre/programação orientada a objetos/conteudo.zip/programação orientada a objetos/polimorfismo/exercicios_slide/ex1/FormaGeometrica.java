package ex1;

public class FormaGeometrica {
	 public double base;
	 public double altura;
	
	 public double calcularArea() {
		 return base * altura;
	 }
}
