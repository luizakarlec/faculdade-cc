package sobreescrita;

public class Passarinho extends Animal {
	@Override
	public void emitirSom() {
		System.out.println("piu piu");
	}
}
