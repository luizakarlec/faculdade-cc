package sobreescrita;

public class Animal {
	public String nome;
	
	public void emitirSom() {
		System.out.println("Animal emitindo som ...");
	}
}
