package jogo_rapido2;

public class Principal {

	public static void main(String[] args) {
		PessoaOi p = new PessoaOi();
		p.dizerOla();
		p.dizerOla("luiza");
	}
}
