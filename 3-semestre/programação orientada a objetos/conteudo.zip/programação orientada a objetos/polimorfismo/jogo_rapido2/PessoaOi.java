package jogo_rapido2;

public class PessoaOi {
	public void dizerOla() {
		System.out.println("Olá!");
	}
	
	public void dizerOla(String nome) {
		System.out.println("Olá, "+nome+"!");
	}
}
