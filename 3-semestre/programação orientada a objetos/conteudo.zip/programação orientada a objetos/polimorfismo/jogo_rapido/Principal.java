package jogo_rapido;

public class Principal {

	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		p.trabalhar();
		p = new Programador();
		p.trabalhar();
	}
}
