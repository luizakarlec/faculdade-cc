package jogo_rapido;

public class Pessoa {

	public void trabalhar() {
		System.out.println("trabalhando...");
	}
}
