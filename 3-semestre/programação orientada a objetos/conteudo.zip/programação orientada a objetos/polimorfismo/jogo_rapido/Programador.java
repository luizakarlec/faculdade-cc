package jogo_rapido;

public class Programador extends Pessoa {
	
	@Override
	public void trabalhar() {
		System.out.println("programando...");
	}
}
