package exemplo;

public class Onibus extends Carro{
	//classe Onibus extende Carro
	protected String modelo;
	
	public String getModelo() {
		return modelo;
	}
	
	public void setModdelo(String modelo) {
		this.modelo = modelo;
	}
}
