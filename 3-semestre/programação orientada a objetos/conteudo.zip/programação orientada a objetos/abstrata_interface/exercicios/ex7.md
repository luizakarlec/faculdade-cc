7) Analisando os exercícios anteriores, quais implementações podem ser desenvolvidas com interface?
Todos em que não haja a necessidade de compartilhar atributos e métodos concretos entre as classes filhas.
Interface serve apenas para garantir que as classes que a implementam tenham determinados métodos.
