package interface1;

public interface Animal {
	void emitirSom();
	void exibeDados();
}
