package interface2;

interface PC {
	public void verificaEmail();
}
