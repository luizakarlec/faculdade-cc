package interface2;

interface Celular {
	public void realizarChamada();
}
