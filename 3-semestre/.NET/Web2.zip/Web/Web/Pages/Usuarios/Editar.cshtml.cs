using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web.Pages.Usuarios
{
    public class EditarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
