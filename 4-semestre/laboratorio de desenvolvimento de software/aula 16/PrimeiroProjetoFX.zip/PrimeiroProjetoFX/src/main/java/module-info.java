module com.example.primeiroprojetofx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.primeiroprojetofx to javafx.fxml;
    exports com.example.primeiroprojetofx;
}