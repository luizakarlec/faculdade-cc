module luiza.projetopessoa {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens luiza.projetopessoa to javafx.fxml;
    exports luiza.projetopessoa;
    exports luiza.projetopessoa.db;
    opens luiza.projetopessoa.db to javafx.fxml;
    exports luiza.projetopessoa.model;
    opens luiza.projetopessoa.model to javafx.fxml;
    opens luiza.projetopessoa.controller to javafx.fxml;
}