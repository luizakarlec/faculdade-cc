package com.example.aulabdapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaBdapiApplication {

    public static void main(String[] args) {
        SpringApplication.run(AulaBdapiApplication.class, args);
    }

}
