package com.example.aulabdapi.controller;

import com.example.aulabdapi.model.Pessoa;
import com.example.aulabdapi.repository.PessoaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pessoas")
public class PessoaController {

    private final PessoaRepository pessoaRepository;

    public PessoaController(PessoaRepository pessoaRepository) {
        super();
        this.pessoaRepository = pessoaRepository;
    }

    @GetMapping
    public List<Pessoa> listar() {
        return pessoaRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pessoa> pesquisarPessoa(@PathVariable long id) {
        if (!pessoaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        Pessoa pessoaEncontrada = pessoaRepository.findById(id).get();
        if (pessoaEncontrada != null) {
            return ResponseEntity.ok(pessoaEncontrada);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/idioma/{idioma}")
    public ResponseEntity<Pessoa> pesquisarPessoaIdioma(@PathVariable String idioma) {
        if (!pessoaRepository.existsPessoaByIdioma(idioma)) {
            return ResponseEntity.notFound().build();
        }
        Pessoa pessoaEncontrada = pessoaRepository.findByIdioma(idioma);

        if (pessoaEncontrada != null) {
            return ResponseEntity.ok(pessoaEncontrada);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Pessoa adicionar(@RequestBody Pessoa pessoa) {
        return pessoaRepository.save(pessoa);
    }

    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<Pessoa> deletarPessoa(@PathVariable Long id) {
        if(!pessoaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        pessoaRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/atualizar/{id}")
    public ResponseEntity<Pessoa> atualizarPessoa(@PathVariable Long id, @RequestBody Pessoa pessoaAtualizado) {
        if (!pessoaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        Pessoa pessoaExistente = pessoaRepository.findById(id).orElse(null);

        if (pessoaExistente != null) {
            pessoaExistente.setNome(pessoaAtualizado.getNome());
            pessoaExistente.setSexo(pessoaAtualizado.getSexo());
            pessoaExistente.setIdioma(pessoaAtualizado.getIdioma());

            Pessoa pessoaAtualizadoNoBanco = pessoaRepository.save(pessoaExistente);
            return ResponseEntity.ok(pessoaAtualizadoNoBanco);
        } else {
            return ResponseEntity.notFound().build();
        }
    }


}
